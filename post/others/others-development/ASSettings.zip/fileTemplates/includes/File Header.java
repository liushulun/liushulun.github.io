/**
* ${USER}, ${YEAR}/${MONTH}/${DAY} - ${HOUR}:${MINUTE}
*/